package com.whatwasmissing.spawnannouncements.util;

import net.minecraft.core.BlockPos;
import net.minecraft.resources.ResourceKey;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.biome.Biome;
import net.minecraft.server.level.ServerLevel;

import java.util.Locale;

/** Converts a precise biome identifier into a broad, non-locating region label. */
public final class BiomeRegionUtil {
    private BiomeRegionUtil() {}

    public static String describe(ServerLevel level, BlockPos position) {
        ResourceKey<Level> dimension = level.dimension();
        if (dimension == Level.NETHER) {
            return "the Nether";
        }
        if (dimension == Level.END) {
            return "the End";
        }

        String path = level.getBiome(position).unwrapKey()
                .map(key -> key.location().getPath())
                .orElse("wilds")
                .toLowerCase(Locale.ROOT);

        if (contains(path, "deep_dark", "dripstone", "lush_cave", "cave")) return "the underground";
        if (contains(path, "snow", "ice", "frozen", "grove", "peaks", "mountain", "jagged")) return "the frozen highlands";
        if (contains(path, "ocean", "river", "beach", "shore", "coast")) return "the waterside";
        if (contains(path, "swamp", "mangrove")) return "the wetlands";
        if (contains(path, "jungle", "bamboo")) return "the jungle";
        if (contains(path, "savanna")) return "the savanna";
        if (contains(path, "desert", "badlands", "mesa")) return "the drylands";
        if (contains(path, "taiga")) return "the taiga";
        if (contains(path, "forest", "wooded")) return "the forest";
        if (contains(path, "plains", "meadow", "cherry", "flower")) return "the grasslands";
        if (contains(path, "mushroom")) return "the mushroom islands";
        if (contains(path, "nether")) return "the Nether";
        if (contains(path, "end")) return "the End";
        return "the wilds";
    }

    private static boolean contains(String value, String... candidates) {
        for (String candidate : candidates) {
            if (value.contains(candidate)) return true;
        }
        return false;
    }
}
