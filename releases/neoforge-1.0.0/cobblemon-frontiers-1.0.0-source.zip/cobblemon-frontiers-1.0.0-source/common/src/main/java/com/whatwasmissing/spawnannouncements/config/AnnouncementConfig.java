package com.whatwasmissing.spawnannouncements.config;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonParseException;
import com.whatwasmissing.spawnannouncements.core.AnnouncementKind;
import org.slf4j.Logger;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.LinkedHashMap;
import java.util.Locale;
import java.util.Map;

/** Server-owned configuration. A fresh file is deliberately conservative. */
public final class AnnouncementConfig {
    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();

    public boolean enabled = true;
    public boolean announceShiny = true;
    public boolean announceLegendary = true;
    public boolean announceMythical = true;
    public boolean announceUltraBeast = true;
    public boolean announceParadox = true;
    public boolean announceAlpha = true;
    // Rare spawn buckets are capture bounties, not public announcements.
    public boolean announceUltraRareSpawns = true;
    public boolean announceRareSpawns = false;
    public boolean includeRegion = true;
    /** Adds the nearest eligible player's name to public alerts, never their location. */
    public boolean announceNearbyPlayerName = true;
    public int nearbyPlayerRadiusBlocks = 96;
    public int globalCooldownSeconds = 45;
    public int sameKindCooldownSeconds = 90;

    /** Empty means every dimension. Values use identifiers such as minecraft:overworld. */
    public java.util.List<String> allowedDimensions = new java.util.ArrayList<>();

    /** Supported placeholders: {region}, {player}, and {player_clause}; coordinate placeholders are scrubbed. */
    public Map<String, String> messages = defaultMessages();

    public boolean isEnabled(AnnouncementKind kind) {
        return switch (kind) {
            case SHINY_LEGENDARY, SHINY_MYTHICAL, SHINY_ULTRA_BEAST, SHINY_ALPHA, SHINY_PARADOX, SHINY -> announceShiny;
            case LEGENDARY -> announceLegendary;
            case MYTHICAL -> announceMythical;
            case ULTRA_BEAST -> announceUltraBeast;
            case PARADOX -> announceParadox;
            case ALPHA -> announceAlpha;
            case ULTRA_RARE -> announceUltraRareSpawns;
            case RARE -> announceRareSpawns;
        };
    }

    public String messageFor(AnnouncementKind kind, String region) {
        return messageFor(kind, region, "");
    }

    public String messageFor(AnnouncementKind kind, String region, String nearbyPlayerName) {
        String template = messages.getOrDefault(kind.id(), defaultMessages().get(kind.id()));
        if (template == null || template.isBlank()) {
            template = "An unusual Pokémon has appeared somewhere in {region}.";
        }
        String safeRegion = includeRegion ? region : "the wilds";
        String safePlayer = safePlayerName(nearbyPlayerName);
        if (!announceNearbyPlayerName) safePlayer = "";
        String clause = safePlayer.isBlank() ? "" : " near " + safePlayer;
        String message = template.replace("{region}", safeRegion)
                .replace("{player_clause}", clause)
                .replace("{player}", safePlayer)
                .replace("{player_name}", safePlayer)
                // Keep the privacy guarantee even if a copied config contains old alert placeholders.
                .replace("{coordinates}", "the wilds")
                .replace("{coords}", "the wilds")
                .replace("{species}", "an unusual Pokémon")
                .replace("{pokemon}", "an unusual Pokémon");
        // Older generated configs won't have the new clause token. Preserve their
        // wording while still honouring the named-nearby-player setting.
        if (!safePlayer.isBlank() && !template.contains("{player_clause}")
                && !template.contains("{player}") && !template.contains("{player_name}")) {
            if (message.endsWith(".")) return message.substring(0, message.length() - 1) + clause + ".";
            return message + clause;
        }
        return message;
    }

    private static String safePlayerName(String value) {
        if (value == null || !value.matches("[A-Za-z0-9_]{1,16}")) return "";
        return value;
    }

    public static AnnouncementConfig load(Path path, Logger logger) {
        AnnouncementConfig config = null;
        try {
            if (Files.exists(path)) {
                String json = Files.readString(path, StandardCharsets.UTF_8);
                config = GSON.fromJson(json, AnnouncementConfig.class);
            }
        } catch (IOException | JsonParseException | IllegalStateException exception) {
            logger.error("Could not read {}. Recreating the default configuration.", path, exception);
        }

        if (config == null) {
            config = new AnnouncementConfig();
        }
        config.applyDefaultsAndLimits();
        save(path, config, logger);
        return config;
    }

    public static void save(Path path, AnnouncementConfig config, Logger logger) {
        try {
            Files.createDirectories(path.getParent());
            Files.writeString(path, GSON.toJson(config), StandardCharsets.UTF_8);
        } catch (IOException exception) {
            logger.error("Could not save {}.", path, exception);
        }
    }

    private void applyDefaultsAndLimits() {
        // Keep the legacy rare field for config compatibility, but enforce the
        // design: rare buckets are always silent and pay out on capture.
        announceRareSpawns = false;
        globalCooldownSeconds = clamp(globalCooldownSeconds, 0, 86_400);
        sameKindCooldownSeconds = clamp(sameKindCooldownSeconds, 0, 86_400);
        nearbyPlayerRadiusBlocks = clamp(nearbyPlayerRadiusBlocks, 1, 512);
        if (allowedDimensions == null) {
            allowedDimensions = new java.util.ArrayList<>();
        }
        if (messages == null) {
            messages = new LinkedHashMap<>();
        }
        Map<String, String> defaults = defaultMessages();
        defaults.forEach(messages::putIfAbsent);
        allowedDimensions.replaceAll(value -> value == null ? "" : value.toLowerCase(Locale.ROOT));
        allowedDimensions.removeIf(String::isBlank);
    }

    private static int clamp(int value, int min, int max) {
        return Math.max(min, Math.min(max, value));
    }

    public static Map<String, String> defaultMessages() {
        Map<String, String> defaults = new LinkedHashMap<>();
        defaults.put("shiny_legendary", "A legendary Pokémon with an otherworldly gleam has appeared somewhere in {region}{player_clause}.");
        defaults.put("shiny_mythical", "A mythical Pokémon with an otherworldly gleam has appeared somewhere in {region}{player_clause}.");
        defaults.put("shiny_ultra_beast", "An Ultra Beast with an otherworldly gleam has appeared somewhere in {region}{player_clause}.");
        defaults.put("shiny_alpha", "A massive Pokémon with an otherworldly gleam has appeared somewhere in {region}{player_clause}.");
        defaults.put("shiny_paradox", "A strange gleam has been seen around a Paradox Pokémon somewhere in {region}{player_clause}.");
        defaults.put("shiny", "A strange sparkle has been spotted somewhere in {region}{player_clause}.");
        defaults.put("legendary", "A legendary presence has been detected somewhere in {region}{player_clause}.");
        defaults.put("mythical", "A mythical presence has been detected somewhere in {region}{player_clause}.");
        defaults.put("ultra_beast", "An Ultra Beast has breached reality somewhere in {region}{player_clause}.");
        defaults.put("paradox", "A temporal anomaly has been detected somewhere in {region}{player_clause}.");
        defaults.put("alpha", "A massive Pokémon has been disturbed somewhere in {region}{player_clause}.");
        defaults.put("ultra_rare", "An exceptionally rare Pokémon has appeared somewhere in {region}{player_clause}.");
        defaults.put("rare", "An unusual Pokémon has appeared somewhere in {region}{player_clause}.");
        return defaults;
    }
}
