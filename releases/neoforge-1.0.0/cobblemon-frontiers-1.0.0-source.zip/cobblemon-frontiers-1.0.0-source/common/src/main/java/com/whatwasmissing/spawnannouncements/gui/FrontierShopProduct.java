package com.whatwasmissing.spawnannouncements.gui;

import net.minecraft.ChatFormatting;
import net.minecraft.core.component.DataComponents;
import net.minecraft.network.chat.Component;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;

public record FrontierShopProduct(
        String id,
        String displayName,
        Item item,
        int amount,
        int cost,
        ChatFormatting colour
) {
    public ItemStack displayStack() {
        ItemStack stack = new ItemStack(item, amount);
        stack.set(DataComponents.CUSTOM_NAME, Component.literal(displayName + " · " + cost + " research")
                .withStyle(colour));
        return stack;
    }

    public ItemStack rewardStack() {
        return new ItemStack(item, amount);
    }
}
