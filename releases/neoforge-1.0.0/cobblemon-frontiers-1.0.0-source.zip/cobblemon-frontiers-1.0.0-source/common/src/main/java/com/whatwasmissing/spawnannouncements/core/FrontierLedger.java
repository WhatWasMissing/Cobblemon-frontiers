package com.whatwasmissing.spawnannouncements.core;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonParseException;
import com.cobblemon.mod.common.pokemon.Pokemon;
import com.whatwasmissing.spawnannouncements.util.BiomeRegionUtil;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.server.level.ServerLevel;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import java.time.LocalDate;
import java.time.ZoneOffset;
import java.util.stream.Collectors;

/**
 * Small persistent server ledger for the Frontier Signals layer.
 *
 * It intentionally stores only broad regions and anonymous signal metadata.
 * Species names and coordinates are never written to disk.
 */
public final class FrontierLedger {
    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
    private static final int MAX_SIGNALS = 24;
    private static final long SIGNAL_LIFETIME_MILLIS = 15 * 60 * 1000L;
    private static final long RARE_SPAWN_LIFETIME_MILLIS = 30 * 60 * 1000L;

    private final Path path;
    private final LedgerData data;

    private FrontierLedger(Path path, LedgerData data) {
        this.path = path;
        this.data = data;
    }

    public static FrontierLedger load(Path path, org.slf4j.Logger logger) {
        LedgerData data = new LedgerData();
        try {
            if (Files.exists(path)) {
                LedgerData loaded = GSON.fromJson(Files.readString(path, StandardCharsets.UTF_8), LedgerData.class);
                if (loaded != null) data = loaded;
            }
        } catch (IOException | JsonParseException | IllegalStateException exception) {
            logger.error("Could not read frontier ledger {}. Starting with an empty ledger.", path, exception);
        }
        data.normalise();
        FrontierLedger ledger = new FrontierLedger(path, data);
        ledger.prune(System.currentTimeMillis());
        ledger.save(logger);
        return ledger;
    }

    public synchronized void save(org.slf4j.Logger logger) {
        try {
            Files.createDirectories(path.getParent());
            Files.writeString(path, GSON.toJson(data), StandardCharsets.UTF_8);
        } catch (IOException exception) {
            logger.error("Could not save frontier ledger {}.", path, exception);
        }
    }

    public synchronized void addSignal(AnnouncementKind kind, String region, String dimension, UUID pokemonUuid, org.slf4j.Logger logger) {
        prune(System.currentTimeMillis());
        SignalRecord record = new SignalRecord();
        record.id = UUID.randomUUID().toString();
        record.pokemonUuid = pokemonUuid.toString();
        record.kind = kind.id();
        record.region = region;
        record.dimension = dimension;
        record.createdAt = System.currentTimeMillis();
        record.status = "active";
        data.signals.add(0, record);
        while (data.signals.size() > MAX_SIGNALS) data.signals.remove(data.signals.size() - 1);
        save(logger);
    }

    /**
     * Remembers a rare spawn privately so a later capture can earn its bounty.
     * Unlike a public signal, this record contains no species, region, or
     * coordinates and is never rendered in the dashboard.
     */
    public synchronized void rememberRareSpawn(UUID pokemonUuid, AnnouncementKind kind, org.slf4j.Logger logger) {
        if (kind != AnnouncementKind.RARE) return;
        prune(System.currentTimeMillis());
        RareSpawnRecord record = new RareSpawnRecord();
        record.kind = kind.id();
        record.createdAt = System.currentTimeMillis();
        data.rareSpawns.put(pokemonUuid.toString(), record);
        save(logger);
    }

    public synchronized AnnouncementKind consumeRareSpawn(UUID pokemonUuid, org.slf4j.Logger logger) {
        prune(System.currentTimeMillis());
        RareSpawnRecord record = data.rareSpawns.remove(pokemonUuid.toString());
        if (record == null) return null;
        save(logger);
        AnnouncementKind kind = AnnouncementKind.fromId(record.kind);
        return kind == AnnouncementKind.RARE ? kind : null;
    }

    public synchronized SignalRecord resolveSignal(UUID pokemonUuid, String status, org.slf4j.Logger logger) {
        prune(System.currentTimeMillis());
        String target = pokemonUuid.toString();
        for (SignalRecord signal : data.signals) {
            if (signal.pokemonUuid.equals(target) && "active".equals(signal.status)) {
                signal.status = status;
                signal.resolvedAt = System.currentTimeMillis();
                save(logger);
                return signal;
            }
        }
        return null;
    }

    public synchronized List<SignalRecord> recentSignals() {
        prune(System.currentTimeMillis());
        return new ArrayList<>(data.signals);
    }

    public synchronized CaptureUpdate recordCapture(ServerPlayer player, Pokemon pokemon, AnnouncementKind rareKind,
                                                    org.slf4j.Logger logger) {
        prune(System.currentTimeMillis());
        String playerId = player.getUUID().toString();
        ResearchProfile profile = data.players.computeIfAbsent(playerId, ignored -> new ResearchProfile());
        resetDailyChallengeIfNeeded(profile, todayUtc());
        ServerLevel serverLevel = (ServerLevel) player.level();
        String region = BiomeRegionUtil.describe(serverLevel, player.blockPosition());
        String dimension = serverLevel.dimension().location().toString();
        int signalBonus = data.signals.stream().anyMatch(signal -> "active".equals(signal.status)
                && region.equals(signal.region)
                && dimension.equals(signal.dimension)) ? 3 : 0;
        if (region.equals(profile.lastRegion)) profile.regionalStreak++;
        else profile.regionalStreak = 1;
        profile.lastRegion = region;
        profile.bestRegionalStreak = Math.max(profile.bestRegionalStreak, profile.regionalStreak);
        int streakBonus = profile.regionalStreak % 5 == 0 ? 2 : 0;
        int rareBonus = rareKind == AnnouncementKind.RARE ? 6 : 0;
        int challengeBonus = 0;
        if (!profile.dailyChallengeCompleted) {
            profile.dailyCaptures = Math.min(DAILY_CAPTURE_GOAL, profile.dailyCaptures + 1);
            if (profile.dailyCaptures >= DAILY_CAPTURE_GOAL) {
                profile.dailyChallengeCompleted = true;
                challengeBonus = DAILY_CAPTURE_REWARD;
            }
        }
        int points = pointsFor(pokemon) + signalBonus + streakBonus + rareBonus + challengeBonus;
        profile.points += points;
        profile.totalEarned += points;

        profile.regionCaptures.merge(region, 1, Integer::sum);
        // This is a breakdown of the same spendable wallet, not an extra
        // reward. It makes regional research actionable without inflating the
        // amount a player can spend.
        profile.regionPoints.merge(region, points, Integer::sum);

        List<Integer> newlyClaimed = new ArrayList<>();
        for (int milestone : MILESTONES) {
            if (profile.totalEarned >= milestone && profile.claimedMilestones.add(milestone)) newlyClaimed.add(milestone);
        }
        save(logger);
        return new CaptureUpdate(points, profile.points, newlyClaimed, region, signalBonus, streakBonus,
                rareBonus, profile.regionalStreak, challengeBonus, profile.dailyCaptures,
                profile.dailyChallengeCompleted);
    }

    public synchronized int pointsFor(Pokemon pokemon) {
        int points = 1;
        if (pokemon.getShiny()) points += 9;
        if (pokemon.isLegendary()) points += 14;
        if (pokemon.isMythical()) points += 14;
        if (pokemon.isUltraBeast()) points += 12;
        if (pokemon.isAlpha()) points += 5;
        return points;
    }

    public synchronized int pointsFor(UUID playerId) {
        ResearchProfile profile = data.players.get(playerId.toString());
        return profile == null ? 0 : profile.points;
    }

    public synchronized int totalEarnedFor(UUID playerId) {
        ResearchProfile profile = data.players.get(playerId.toString());
        return profile == null ? 0 : profile.totalEarned;
    }

    public synchronized boolean spendPoints(UUID playerId, int cost, org.slf4j.Logger logger) {
        if (cost < 0) return false;
        ResearchProfile profile = data.players.get(playerId.toString());
        if (profile == null || profile.points < cost) return false;

        // Ledgers created before regional allocations have a legacy unassigned
        // balance. Spend that first, then consume the regional buckets while
        // keeping the authoritative total exactly equal to `cost`.
        int regionalTotal = profile.regionPoints.values().stream()
                .filter(java.util.Objects::nonNull)
                .mapToInt(value -> Math.max(0, value))
                .sum();
        int legacyBalance = Math.max(0, profile.points - regionalTotal);
        int remaining = Math.max(0, cost - Math.min(cost, legacyBalance));
        if (remaining > 0) {
            int regionalAvailable = Math.min(remaining, regionalTotal);
            if (regionalAvailable < remaining) return false;
            for (Map.Entry<String, Integer> entry : profile.regionPoints.entrySet()) {
                if (remaining <= 0) break;
                int available = Math.max(0, entry.getValue());
                int used = Math.min(available, remaining);
                if (used > 0) {
                    entry.setValue(available - used);
                    remaining -= used;
                }
            }
        }
        profile.points -= cost;
        save(logger);
        return true;
    }

    public synchronized List<LeaderboardEntry> leaderboard() {
        return data.players.entrySet().stream()
                .map(entry -> new LeaderboardEntry(UUID.fromString(entry.getKey()), entry.getValue().totalEarned))
                .sorted(Comparator.comparingInt(LeaderboardEntry::points).reversed())
                .limit(5)
                .collect(Collectors.toList());
    }

    public synchronized int nextMilestone(UUID playerId) {
        ResearchProfile profile = data.players.get(playerId.toString());
        int points = profile == null ? 0 : profile.totalEarned;
        for (int milestone : MILESTONES) if (points < milestone) return milestone;
        return -1;
    }

    public synchronized Map<String, Integer> regionCaptureCounts(UUID playerId) {
        ResearchProfile profile = data.players.get(playerId.toString());
        if (profile == null) return Map.of();
        return new LinkedHashMap<>(profile.regionCaptures);
    }

    /** Each broad region's share of the same spendable research wallet. */
    public synchronized Map<String, Integer> regionResearchPoints(UUID playerId) {
        ResearchProfile profile = data.players.get(playerId.toString());
        if (profile == null) return Map.of();
        return new LinkedHashMap<>(profile.regionPoints);
    }

    public synchronized int currentStreak(UUID playerId) {
        ResearchProfile profile = data.players.get(playerId.toString());
        return profile == null ? 0 : profile.regionalStreak;
    }

    public synchronized int bestStreak(UUID playerId) {
        ResearchProfile profile = data.players.get(playerId.toString());
        return profile == null ? 0 : profile.bestRegionalStreak;
    }

    public synchronized DailyChallengeProgress dailyChallenge(UUID playerId) {
        ResearchProfile profile = data.players.get(playerId.toString());
        if (profile == null || !todayUtc().equals(profile.dailyChallengeDate)) {
            return new DailyChallengeProgress(0, DAILY_CAPTURE_GOAL, false, DAILY_CAPTURE_REWARD);
        }
        return new DailyChallengeProgress(profile.dailyCaptures, DAILY_CAPTURE_GOAL,
                profile.dailyChallengeCompleted, DAILY_CAPTURE_REWARD);
    }

    public static int[] milestones() {
        return MILESTONES.clone();
    }

    private void prune(long now) {
        data.signals.removeIf(signal -> signal == null
                || signal.createdAt <= 0
                || now - signal.createdAt > SIGNAL_LIFETIME_MILLIS && !"active".equals(signal.status));
        data.rareSpawns.entrySet().removeIf(entry -> entry.getKey() == null
                || entry.getValue() == null
                || entry.getValue().createdAt <= 0
                || now - entry.getValue().createdAt > RARE_SPAWN_LIFETIME_MILLIS);
        // Active signals remain visible for the full lifetime, then become historical.
        for (SignalRecord signal : data.signals) {
            if ("active".equals(signal.status) && now - signal.createdAt > SIGNAL_LIFETIME_MILLIS) {
                signal.status = "faded";
                signal.resolvedAt = now;
            }
        }
        while (data.signals.size() > MAX_SIGNALS) data.signals.remove(data.signals.size() - 1);
    }

    private static final int[] MILESTONES = {25, 100, 250, 500};
    private static final int DAILY_CAPTURE_GOAL = 5;
    private static final int DAILY_CAPTURE_REWARD = 10;

    private static String todayUtc() {
        return LocalDate.now(ZoneOffset.UTC).toString();
    }

    private static void resetDailyChallengeIfNeeded(ResearchProfile profile, String today) {
        if (!today.equals(profile.dailyChallengeDate)) {
            profile.dailyChallengeDate = today;
            profile.dailyCaptures = 0;
            profile.dailyChallengeCompleted = false;
        }
    }

    public static final class LedgerData {
        public List<SignalRecord> signals = new ArrayList<>();
        public Map<String, RareSpawnRecord> rareSpawns = new LinkedHashMap<>();
        public Map<String, ResearchProfile> players = new LinkedHashMap<>();

        void normalise() {
            if (signals == null) signals = new ArrayList<>();
            if (rareSpawns == null) rareSpawns = new LinkedHashMap<>();
            if (players == null) players = new LinkedHashMap<>();
            signals.removeIf(signal -> signal == null || signal.pokemonUuid == null);
            rareSpawns.entrySet().removeIf(entry -> entry.getKey() == null || entry.getValue() == null);
            players.values().forEach(ResearchProfile::normalise);
        }
    }

    public static final class RareSpawnRecord {
        public String kind = "rare";
        public long createdAt;
    }

    public static final class SignalRecord {
        public String id = "";
        public String pokemonUuid = "";
        public String kind = "rare";
        public String region = "the wilds";
        public String dimension = "minecraft:overworld";
        public long createdAt;
        public long resolvedAt;
        public String status = "active";

        public AnnouncementKind kindEnum() {
            AnnouncementKind parsed = AnnouncementKind.fromId(kind);
            return parsed == null ? AnnouncementKind.RARE : parsed;
        }
    }

    public static final class ResearchProfile {
        public int points;
        public int totalEarned;
        public Map<String, Integer> regionCaptures = new LinkedHashMap<>();
        /** Regional breakdown of points already included in {@link #points}. */
        public Map<String, Integer> regionPoints = new LinkedHashMap<>();
        public Set<Integer> claimedMilestones = new LinkedHashSet<>();
        public String lastRegion = "";
        public int regionalStreak;
        public int bestRegionalStreak;
        public String dailyChallengeDate = "";
        public int dailyCaptures;
        public boolean dailyChallengeCompleted;

        void normalise() {
            if (regionCaptures == null) regionCaptures = new LinkedHashMap<>();
            if (regionPoints == null) regionPoints = new LinkedHashMap<>();
            if (claimedMilestones == null) claimedMilestones = new LinkedHashSet<>();
            if (lastRegion == null) lastRegion = "";
            if (dailyChallengeDate == null) dailyChallengeDate = "";
            points = Math.max(0, points);
            totalEarned = Math.max(points, totalEarned);
            regionPoints.entrySet().removeIf(entry -> entry.getKey() == null
                    || entry.getValue() == null || entry.getValue() < 0);
            regionalStreak = Math.max(0, regionalStreak);
            bestRegionalStreak = Math.max(regionalStreak, Math.max(0, bestRegionalStreak));
            dailyCaptures = Math.max(0, Math.min(DAILY_CAPTURE_GOAL, dailyCaptures));
            if (dailyCaptures >= DAILY_CAPTURE_GOAL) dailyChallengeCompleted = true;
        }
    }

    public record CaptureUpdate(int pointsEarned, int totalPoints, List<Integer> newMilestones, String region,
                                int signalBonus, int streakBonus, int rareBonus, int regionalStreak,
                                int dailyChallengeBonus, int dailyCaptures, boolean dailyChallengeCompleted) {}
    public record DailyChallengeProgress(int captures, int goal, boolean completed, int reward) {}
    public record LeaderboardEntry(UUID playerId, int points) {}
}
