# Changelog

## 1.0.0

* Added server-side Field Intelligence announcements for shiny, legendary, mythical, Ultra Beast, Paradox, and alpha spawns.
* Rare spawn buckets are silent and award a +6 private capture bounty; ultra-rare buckets are publicly announced anonymously.
* Added broad-region messages with no species, coordinates, player names, or waypoints.
* Added global and per-kind cooldowns plus dimension filtering.
* Added persistent Frontier Signals history and signal-linked capture bonuses.
* Added persistent Field Research points, regional capture summaries, leaderboard, and milestone rewards.
* Added separate lifetime-earned and spendable research balances.
* Added the keybound Frontier Intelligence dashboard with balance, milestones, streaks, anonymous signals, and a paged Cobblemon-inspired custom screen.
* Added a large vanilla and Cobblemon exchange catalogue covering specialty Poké Balls, healing items, Rare Candy, EXP Candy, ability items, evolution stones, and Metal Alloy.
* Added optional registry discovery for Mega Showdown items without making Mega Showdown a required dependency.
* Fixed dashboard overlap in the exchange header, added responsive GUI scaling, and moved page navigation onto reliable menu button packets so previous-page navigation works.
* Hardened keybind opening by avoiding duplicate requests, closing stale containers before opening, and reporting a server-side open failure.
* Added Fabric and NeoForge Minecraft 1.21.1 targets for Cobblemon 1.8.0+.
