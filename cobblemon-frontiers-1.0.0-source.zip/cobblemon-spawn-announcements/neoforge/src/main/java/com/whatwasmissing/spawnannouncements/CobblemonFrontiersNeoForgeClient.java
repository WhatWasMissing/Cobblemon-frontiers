package com.whatwasmissing.spawnannouncements;

import com.mojang.blaze3d.platform.InputConstants;
import com.whatwasmissing.spawnannouncements.core.AnnouncementService;
import com.whatwasmissing.spawnannouncements.gui.FrontierDashboardScreen;
import com.whatwasmissing.spawnannouncements.gui.FrontierMenuTypes;
import com.whatwasmissing.spawnannouncements.network.OpenFrontierShopPayload;
import net.minecraft.client.KeyMapping;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.screens.MenuScreens;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.fml.common.Mod;
import net.neoforged.fml.event.lifecycle.FMLClientSetupEvent;
import net.neoforged.fml.javafmlmod.FMLJavaModLoadingContext;
import net.neoforged.neoforge.client.event.ClientTickEvent;
import net.neoforged.neoforge.client.event.RegisterKeyMappingsEvent;
import net.neoforged.neoforge.common.NeoForge;
import net.neoforged.neoforge.network.PacketDistributor;
import org.lwjgl.glfw.GLFW;

/** Registers the client-side shortcut; the server remains authoritative over the dashboard. */
@Mod(value = AnnouncementService.MOD_ID, dist = Dist.CLIENT)
public final class CobblemonFrontiersNeoForgeClient {
    private static final KeyMapping OPEN_FRONTIER_DASHBOARD = new KeyMapping(
            "key.cobblemon_frontiers.open_exchange",
            InputConstants.Type.KEYSYM,
            GLFW.GLFW_KEY_K,
            "category.cobblemon_frontiers");

    public CobblemonFrontiersNeoForgeClient() {
        FMLJavaModLoadingContext.get().getModEventBus().addListener((FMLClientSetupEvent event) ->
                event.enqueueWork(() -> MenuScreens.register(FrontierMenuTypes.FRONTIER_DASHBOARD, FrontierDashboardScreen::new)));
        FMLJavaModLoadingContext.get().getModEventBus().addListener(CobblemonFrontiersNeoForgeClient::registerKeyMapping);
        NeoForge.EVENT_BUS.addListener(CobblemonFrontiersNeoForgeClient::onClientTick);
    }

    private static void registerKeyMapping(RegisterKeyMappingsEvent event) {
        event.register(OPEN_FRONTIER_DASHBOARD);
    }

    private static void onClientTick(ClientTickEvent.Post event) {
        Minecraft client = Minecraft.getInstance();
        while (OPEN_FRONTIER_DASHBOARD.consumeClick()) {
            if (client.player != null && client.getConnection() != null
                    && !(client.screen instanceof FrontierDashboardScreen)) {
                PacketDistributor.sendToServer(new OpenFrontierShopPayload());
            }
        }
    }
}
