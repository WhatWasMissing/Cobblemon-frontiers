package com.whatwasmissing.spawnannouncements;

import com.whatwasmissing.spawnannouncements.command.AnnouncementCommands;
import com.whatwasmissing.spawnannouncements.core.AnnouncementService;
import com.whatwasmissing.spawnannouncements.gui.FrontierMenuTypes;
import com.whatwasmissing.spawnannouncements.network.OpenFrontierShopPayload;
import net.minecraft.core.registries.BuiltInRegistries;
import net.neoforged.fml.common.Mod;
import net.neoforged.fml.event.lifecycle.FMLCommonSetupEvent;
import net.neoforged.neoforge.common.NeoForge;
import net.neoforged.neoforge.event.RegisterCommandsEvent;
import net.neoforged.fml.loading.FMLPaths;
import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.network.event.RegisterPayloadHandlersEvent;
import net.neoforged.neoforge.network.registration.PayloadRegistrar;
import net.minecraft.server.level.ServerPlayer;

/** NeoForge server entrypoint. */
@Mod(AnnouncementService.MOD_ID)
public final class CobblemonFrontiersNeoForge {
    private static final DeferredRegister<net.minecraft.world.inventory.MenuType<?>> MENU_TYPES =
            DeferredRegister.create(BuiltInRegistries.MENU, AnnouncementService.MOD_ID);

    static {
        MENU_TYPES.register("frontier_dashboard", () -> FrontierMenuTypes.FRONTIER_DASHBOARD);
    }

    public CobblemonFrontiersNeoForge() {
        MENU_TYPES.register(net.neoforged.fml.javafmlmod.FMLJavaModLoadingContext.get().getModEventBus());
        NeoForge.EVENT_BUS.addListener(CobblemonFrontiersNeoForge::registerCommands);
        net.neoforged.fml.javafmlmod.FMLJavaModLoadingContext.get().getModEventBus().addListener(CobblemonFrontiersNeoForge::commonSetup);
        net.neoforged.fml.javafmlmod.FMLJavaModLoadingContext.get().getModEventBus().addListener(CobblemonFrontiersNeoForge::registerPayloads);
    }

    private static void commonSetup(FMLCommonSetupEvent event) {
        AnnouncementService.init(FMLPaths.CONFIGDIR.get());
    }

    private static void registerCommands(RegisterCommandsEvent event) {
        AnnouncementCommands.register(event.getDispatcher());
    }

    private static void registerPayloads(RegisterPayloadHandlersEvent event) {
        PayloadRegistrar registrar = event.registrar("1");
        registrar.playToServer(OpenFrontierShopPayload.TYPE, OpenFrontierShopPayload.CODEC, (payload, context) ->
                context.enqueueWork(() -> {
                    if (context.player() instanceof ServerPlayer player) {
                        AnnouncementService.openShop(player);
                    }
                }));
    }
}
