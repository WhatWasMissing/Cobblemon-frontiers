# Cobblemon Frontiers

Cobblemon Frontiers is a server-side Cobblemon 1.8.0+ add-on for Fabric and NeoForge on Minecraft 1.21.1.

It has two connected systems:

* **Field Intelligence** announces meaningful trait spawns without revealing the species, coordinates, player locations, or waypoints. Shiny, legendary, mythical, Ultra Beast, Paradox, alpha, and ultra-rare spawns can create broad-region notices; rare spawn buckets stay silent and instead pay capture bounties. A typical message is: `A strange sparkle has been spotted somewhere in the savanna.`
* **Frontier Signals** records a short anonymous history of these sightings. Players can read the public board with `/spawnannounce signals`.
* **Field Research** awards persistent research points for captures, with bonus points for shiny, legendary, mythical, Ultra Beast, alpha, and other exceptional Pokémon. Milestones provide small vanilla rewards.
* **Frontier Intelligence dashboard** opens with the default `K` key (rebindable in Controls). It combines your balance, lifetime progress, survey streak, recent anonymous signals, and a paged exchange GUI.
* **Cobblemon exchange** includes Poké Balls, specialty balls, healing items, Rare Candy, EXP Candy, Ability Capsule/Patch, evolution stones, and Metal Alloy alongside a broad vanilla supply catalogue. Mega Showdown items are discovered automatically when that optional mod is installed.
* **Regional Surveys** track broad-region capture streaks and award a small bonus every fifth consecutive capture in the same region.

The mod is server-authoritative. A matching client mod is needed for the keybind and custom dashboard screen; it uses Cobblemon-inspired panels and item cards without requiring a resource pack.

## Commands

* `/spawnannounce signals` — recent anonymous signals and their broad regions.
* `/spawnannounce research` — your field-research points and next milestone.
* `/spawnannounce research regions` — your capture counts by broad region.
* `/spawnannounce research top` — the top five research scores.
* `/spawnannounce reload` — reload `config/cobblemon_frontiers/config.json` (operator only).
* `/spawnannounce status` — show the current alert settings (operator only).
* `/spawnannounce test <kind>` — preview a message without creating a signal (operator only).

## Build

Use Java 21 and run one of:

```text
./gradlew :fabric:build
./gradlew :neoforge:build
```

The finished jars are written to `fabric/build/libs/` and `neoforge/build/libs/`.

For a dependency-free privacy/configuration check, run `sh tools/verify_frontiers.sh`.

## Design notes

See `docs/DESIGN.md`, `docs/RESEARCH.md`, and `docs/default-config.json`.
