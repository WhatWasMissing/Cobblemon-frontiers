# Cobblemon Frontiers — Codex Handoff

## Purpose

This is a Fabric + NeoForge Cobblemon 1.8.1 / Minecraft 1.21.1 mod called **Cobblemon Frontiers**.

The core idea is to make rare spawns feel like a shared world event without turning them into a coordinate giveaway. The mod announces that an unusual Pokémon has appeared in a broad region, then turns exploration and captures into persistent Field Research points that can be spent in an in-game exchange.

Continue from the existing implementation. Do not rewrite the project from scratch.

## Current player experience

### Field Intelligence spawn announcements

The server listens to Cobblemon spawn events and announces only significant spawns:

- shiny
- shiny legendary, mythical, Ultra Beast, alpha, Paradox
- legendary
- mythical
- Ultra Beast
- Paradox
- alpha
- ultra-rare Cobblemon spawn bucket

The highest-priority matching category wins, so one Pokémon creates one coherent announcement instead of several stacked messages.

Cobblemon rare spawn buckets are deliberately silent and tracked privately for capture bounties. Ultra-rare spawn buckets are announced through the normal anonymous broad-region path.

Announcements intentionally reveal only:

- the significance of the spawn
- a broad region such as savanna, wetlands, frozen highlands, or underground

They do **not** reveal:

- species
- coordinates
- X/Y/Z values
- player names
- player positions
- waypoints

Global and per-category cooldowns prevent the server chat from becoming a notification feed. Configuration lives at `config/cobblemon_frontiers/config.json` and can be reloaded by an operator.

### Frontier Signals

Each announcement creates an anonymous signal in the persistent ledger:

- maximum 24 records
- active lifetime of 15 minutes
- broad region and dimension only
- lifecycle status such as active, secured, or faded
- Pokémon UUID is used internally to resolve captures, but species and position are not stored

When a matching Pokémon is captured, the signal is marked secured and the server announces that the signal has gone quiet.

### Field Research

Captures award persistent points:

| Source | Points |
|---|---:|
| Base capture | +1 |
| Shiny | +9 |
| Legendary | +14 |
| Mythical | +14 |
| Ultra Beast | +12 |
| Alpha | +5 |
| Rare spawn bucket | +6 |
| Capture linked to an active regional signal | +3 |
| Every fifth capture in the same broad region | +2 |

Each player profile stores:

- spendable research balance
- lifetime-earned research total
- regional capture counts
- current regional streak
- best regional streak
- claimed milestones

Milestones are currently 25, 100, 250, and 500 lifetime-earned points. Lifetime points drive milestones and the leaderboard; spending points only reduces the spendable balance.

### Keybind and dashboard

The default keybind is **K**, and it is rebindable in Minecraft Controls.

The keybind sends a small custom payload to the server. It does not execute `/spawnannounce shop` or any other command. The server opens a registered mod-owned dashboard menu, and purchases are validated server-side.

The old shop command has been removed. Report/admin commands remain:

- `/spawnannounce signals`
- `/spawnannounce research`
- `/spawnannounce research regions`
- `/spawnannounce research top`
- `/spawnannounce reload` (operator)
- `/spawnannounce status` (operator)
- `/spawnannounce test <kind>` (operator)

## Approved GUI direction

The user approved the generated visual direction: a custom Cobblemon-inspired dark teal interface rather than a vanilla chest.

The intended screen has:

- a dark navy/blue-gray main panel
- cyan/teal accent lines and active states
- a header reading **FRONTIER INTELLIGENCE**
- **Overview** and **Exchange** tabs
- compact research balance, lifetime total, and streak status chips
- anonymous signal cards using broad regions only
- item cards with item icon, name, quantity, research cost, and a clear **BUY** affordance
- previous/next page controls
- no visible vanilla chest slot grid
- no species, coordinates, or player locations

The current custom screen is code-drawn and uses Minecraft item rendering. It is intentionally resource-pack-free. The current code has signal cards on the Overview tab and the full-width item-card grid on the Exchange tab. The generated mockup showed a possible future refinement with a left-side signal rail beside the exchange grid; that is approved as a design direction, not yet an exact implementation requirement.

## Current implementation layout

### Common code

- `common/src/main/java/com/whatwasmissing/spawnannouncements/core/AnnouncementService.java`
  - event subscriptions, announcements, research accessors, menu opening
- `common/src/main/java/com/whatwasmissing/spawnannouncements/core/FrontierLedger.java`
  - persistent signals and player research profiles
- `common/src/main/java/com/whatwasmissing/spawnannouncements/config/AnnouncementConfig.java`
  - config loading and message templates
- `common/src/main/java/com/whatwasmissing/spawnannouncements/gui/FrontierShopCatalog.java`
  - broad vanilla + Cobblemon product catalog and optional Mega Showdown registry discovery
- `common/src/main/java/com/whatwasmissing/spawnannouncements/gui/FrontierShopProduct.java`
  - product definition and display/reward stacks
- `common/src/main/java/com/whatwasmissing/spawnannouncements/gui/FrontierShopMenu.java`
  - server-authoritative backing menu, product slots, button-based page state, purchase handling
- `common/src/main/java/com/whatwasmissing/spawnannouncements/gui/FrontierDashboardScreen.java`
  - custom Cobblemon-inspired client presentation
- `common/src/main/java/com/whatwasmissing/spawnannouncements/gui/FrontierMenuTypes.java`
  - shared registered menu type
- `common/src/main/java/com/whatwasmissing/spawnannouncements/network/OpenFrontierShopPayload.java`
  - keybind-to-server open request

### Loader code

Fabric:

- `fabric/src/main/java/com/whatwasmissing/spawnannouncements/CobblemonFrontiersFabric.java`
  - menu registry, commands, server payload receiver
- `fabric/src/main/java/com/whatwasmissing/spawnannouncements/CobblemonFrontiersFabricClient.java`
  - menu screen registration and K keybind
- `fabric/src/main/resources/fabric.mod.json`
  - main and client entrypoints

NeoForge:

- `neoforge/src/main/java/com/whatwasmissing/spawnannouncements/CobblemonFrontiersNeoForge.java`
  - deferred menu registration, commands, payload registration
- `neoforge/src/main/java/com/whatwasmissing/spawnannouncements/CobblemonFrontiersNeoForgeClient.java`
  - screen registration and K keybind

## Exchange catalog

The catalog starts with vanilla supplies and dynamically resolves Cobblemon registry IDs, omitting unavailable optional entries instead of substituting another item.

It currently includes:

- vanilla experience bottles, amethyst, gold, glow berries, ender pearls, compass, golden apple, diamond
- additional vanilla food, light, travel, Nether, End, and emergency supplies
- Poké Ball, Great Ball, Ultra Ball, Premier Ball, Dusk Ball, Quick Ball, Repeat Ball, Timer Ball, Net Ball, Dive Ball, Luxury Ball, Heal Ball, Beast Ball, Master Ball
- Potion, Super Potion, Hyper Potion, Full Restore, Revive, Max Revive
- Rare Candy, EXP Candy L, EXP Candy XL
- Ability Capsule, Ability Patch
- Everstone, Fire Stone, Water Stone, Thunder Stone, Leaf Stone, Ice Stone, Metal Alloy
- additional specialty Poké Balls and evolution stones when registered by Cobblemon
- Mega Showdown items discovered by namespace when Mega Showdown is installed; no hard dependency is added

The catalog currently uses 12 products per page.

## Privacy and safety requirements

Preserve these promises when extending the mod:

1. Never include species or precise positions in public announcements.
2. Never write coordinates or species names to the Frontier Signals ledger.
3. Keep purchase validation on the server.
4. Never trust client-supplied item cost or reward data.
5. Keep keybind/UI packets limited to opening, navigation, and requesting an existing server-defined purchase.
6. Do not add a minimap, waypoint, tracking arrow, or location broadcast unless the user explicitly changes the design goal.

## Validation and build status

The static validation command passes:

```text
sh tools/verify_frontiers.sh
```

The project targets Java 21. The prior workspace only had Java 17 and could not reach Gradle’s distribution server, so a Gradle compile was not completed there. Before shipping, run:

```text
./gradlew :fabric:build
./gradlew :neoforge:build
```

Then test on both loaders with Cobblemon 1.8.1:

1. Join with the client companion installed.
2. Press K and verify the custom screen opens.
3. Switch Overview/Exchange tabs.
4. Click page arrows.
5. Capture Pokémon to earn points.
6. Buy vanilla and Cobblemon items.
7. Confirm insufficient balance does not grant an item.
8. Click forward, then previous, across several exchange pages.
9. Capture a rare spawn and confirm the private +6 bounty appears without a spawn announcement; verify an ultra-rare spawn creates an anonymous announcement.
10. Reconnect and confirm balances persist.
11. Verify no announcement includes species or coordinates.

## Handoff expectation

Treat the current GUI as the approved visual foundation. If improving it, prioritize:

- better responsive scaling for smaller Minecraft windows
- a left-side signal rail beside the exchange grid if it fits cleanly
- item hover tooltips and clearer purchase feedback inside the GUI
- texture-backed panel accents only if they genuinely improve the Cobblemon feel
- loader-specific compile/runtime verification before changing the server model

Do not revert to a generic chest screen or reintroduce the shop command as the primary interaction.
