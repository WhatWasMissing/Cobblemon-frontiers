package com.whatwasmissing.spawnannouncements.command;

import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.arguments.StringArgumentType;
import com.mojang.brigadier.builder.LiteralArgumentBuilder;
import com.mojang.brigadier.context.CommandContext;
import com.whatwasmissing.spawnannouncements.core.AnnouncementKind;
import com.whatwasmissing.spawnannouncements.core.AnnouncementService;
import com.whatwasmissing.spawnannouncements.core.FrontierLedger;
import net.minecraft.ChatFormatting;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.commands.Commands;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;

import java.util.List;
import java.util.Map;

/** Operator tools and player-facing field-intelligence reports. */
public final class AnnouncementCommands {
    private AnnouncementCommands() {}

    public static void register(CommandDispatcher<CommandSourceStack> dispatcher) {
        LiteralArgumentBuilder<CommandSourceStack> root = Commands.literal("spawnannounce")
                .then(Commands.literal("signals").executes(AnnouncementCommands::showSignals))
                .then(Commands.literal("research").executes(AnnouncementCommands::showResearch)
                        .then(Commands.literal("regions").executes(AnnouncementCommands::showRegions))
                        .then(Commands.literal("top").executes(AnnouncementCommands::showLeaderboard)))
                .then(Commands.literal("reload")
                        .requires(source -> source.hasPermission(2))
                        .executes(AnnouncementCommands::reload))
                .then(Commands.literal("status")
                        .requires(source -> source.hasPermission(2))
                        .executes(AnnouncementCommands::status))
                .then(Commands.literal("test")
                        .requires(source -> source.hasPermission(2))
                        .then(Commands.argument("kind", StringArgumentType.word())
                                .executes(AnnouncementCommands::test)));
        dispatcher.register(root);
    }

    private static int showSignals(CommandContext<CommandSourceStack> context) {
        CommandSourceStack source = context.getSource();
        List<FrontierLedger.SignalRecord> signals = AnnouncementService.recentSignals();
        if (signals.isEmpty()) {
            source.sendSuccess(() -> Component.literal("No recent field signals are on record.").withStyle(ChatFormatting.GRAY), false);
            return 1;
        }

        source.sendSuccess(() -> Component.literal("── Active field signals ──").withStyle(ChatFormatting.AQUA), false);
        long now = System.currentTimeMillis();
        signals.stream().limit(8).forEach(signal -> {
            long ageSeconds = Math.max(0L, (now - signal.createdAt) / 1000L);
            String line = "• " + signal.kindEnum().displayName() + " · " + signal.region
                    + " · " + signal.status + " · " + ageSeconds + "s ago";
            source.sendSuccess(() -> Component.literal(line).withStyle(signal.status.equals("active") ? ChatFormatting.GREEN : ChatFormatting.GRAY), false);
        });
        return 1;
    }

    private static int showResearch(CommandContext<CommandSourceStack> context) {
        if (!(context.getSource().getEntity() instanceof ServerPlayer player)) {
            context.getSource().sendFailure(Component.literal("This report must be viewed by a player."));
            return 0;
        }
        int points = AnnouncementService.points(player.getUUID());
        int totalEarned = AnnouncementService.totalEarned(player.getUUID());
        int next = AnnouncementService.nextMilestone(player.getUUID());
        String nextText = next < 0 ? "all standard milestones complete" : next + " points";
        player.sendSystemMessage(Component.literal("── Field research ──").withStyle(ChatFormatting.AQUA));
        player.sendSystemMessage(Component.literal("Research balance: " + points + " · lifetime earned: " + totalEarned + " · next milestone: " + nextText)
                .withStyle(ChatFormatting.WHITE));
        player.sendSystemMessage(Component.literal("Regional streak: " + AnnouncementService.currentStreak(player.getUUID())
                        + " · best: " + AnnouncementService.bestStreak(player.getUUID()))
                .withStyle(ChatFormatting.WHITE));
        player.sendSystemMessage(Component.literal("Captures award more points for shiny, alpha, Paradox, Ultra Beast, mythical, and legendary Pokémon.")
                .withStyle(ChatFormatting.GRAY));
        return 1;
    }

    private static int showRegions(CommandContext<CommandSourceStack> context) {
        if (!(context.getSource().getEntity() instanceof ServerPlayer player)) {
            context.getSource().sendFailure(Component.literal("This report must be viewed by a player."));
            return 0;
        }
        Map<String, Integer> counts = AnnouncementService.regionCaptureCounts(player.getUUID());
        player.sendSystemMessage(Component.literal("── Surveyed regions ──").withStyle(ChatFormatting.AQUA));
        if (counts.isEmpty()) {
            player.sendSystemMessage(Component.literal("No regional captures recorded yet.").withStyle(ChatFormatting.GRAY));
            return 1;
        }
        counts.entrySet().stream()
                .sorted(Map.Entry.<String, Integer>comparingByValue().reversed())
                .forEach(entry -> player.sendSystemMessage(Component.literal(entry.getKey() + " · " + entry.getValue() + " captures")
                        .withStyle(ChatFormatting.WHITE)));
        return 1;
    }

    private static int showLeaderboard(CommandContext<CommandSourceStack> context) {
        context.getSource().sendSuccess(() -> Component.literal("── Field research leaders ──").withStyle(ChatFormatting.GOLD), false);
        int rank = 1;
        for (FrontierLedger.LeaderboardEntry entry : AnnouncementService.leaderboard()) {
            String name = context.getSource().getServer().getProfileCache()
                    .get(entry.playerId()).map(profile -> profile.getName()).orElse(entry.playerId().toString());
            int currentRank = rank++;
            context.getSource().sendSuccess(() -> Component.literal("#" + currentRank + " " + name + " · " + entry.points() + " points"), false);
        }
        return 1;
    }

    private static int reload(CommandContext<CommandSourceStack> context) {
        AnnouncementService.reload();
        context.getSource().sendSuccess(() -> Component.literal("Cobblemon Frontiers configuration reloaded."), true);
        return 1;
    }

    private static int status(CommandContext<CommandSourceStack> context) {
        context.getSource().sendSuccess(() -> Component.literal("Cobblemon Frontiers: " + AnnouncementService.statusLine()), false);
        return 1;
    }

    private static int test(CommandContext<CommandSourceStack> context) {
        String requested = StringArgumentType.getString(context, "kind");
        AnnouncementKind kind = AnnouncementService.parseKind(requested);
        if (kind == null) {
            context.getSource().sendFailure(Component.literal("Unknown kind. Try rare, shiny, legendary, mythical, ultra_beast, paradox, or alpha."));
            return 0;
        }
        context.getSource().sendSuccess(() -> AnnouncementService.format(kind,
                AnnouncementService.config().messageFor(kind, "the savanna")), false);
        return 1;
    }
}
