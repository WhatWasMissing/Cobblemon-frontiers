package com.whatwasmissing.spawnannouncements.gui;

import com.whatwasmissing.spawnannouncements.core.AnnouncementService;
import com.whatwasmissing.spawnannouncements.core.FrontierLedger;
import net.minecraft.ChatFormatting;
import net.minecraft.network.chat.Component;
import net.minecraft.world.SimpleContainer;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.inventory.ChestMenu;
import net.minecraft.world.inventory.ClickType;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.server.level.ServerPlayer;

import java.util.List;

/** Server-owned data/menu backing the client-side Frontier Intelligence screen. */
public final class FrontierShopMenu extends ChestMenu {
    /** Button ids used by the custom Cobblemon-style screen. */
    public static final int BUTTON_PREVIOUS_PAGE = 0;
    public static final int BUTTON_NEXT_PAGE = 1;

    private static final int SHOP_SIZE = 54;
    private static final int[] PRODUCT_SLOTS = {
            27, 28, 29, 30, 31, 32, 33, 34, 35,
            36, 37, 38
    };
    private static final int[] SIGNAL_SLOTS = {18, 19, 20, 21, 22, 23, 24, 25, 26};

    private final SimpleContainer shopInventory;
    private int page;

    public FrontierShopMenu(int containerId, Inventory playerInventory) {
        this(containerId, playerInventory, new SimpleContainer(SHOP_SIZE));
    }

    private FrontierShopMenu(int containerId, Inventory playerInventory, SimpleContainer shopInventory) {
        super(FrontierMenuTypes.FRONTIER_DASHBOARD, containerId, playerInventory, shopInventory, 6);
        this.shopInventory = shopInventory;
        populate(playerInventory.player);
    }

    private void populate(Player player) {
        for (int slot = 0; slot < SHOP_SIZE; slot++) {
            shopInventory.setItem(slot, pane(Items.GRAY_STAINED_GLASS_PANE));
        }
        shopInventory.setItem(4, balanceStack(player));
        shopInventory.setItem(13, surveyStack(player));

        List<FrontierLedger.SignalRecord> signals = AnnouncementService.recentSignals();
        for (int index = 0; index < signals.size() && index < SIGNAL_SLOTS.length; index++) {
            shopInventory.setItem(SIGNAL_SLOTS[index], signalStack(signals.get(index)));
        }

        List<FrontierShopProduct> products = FrontierShopCatalog.products();
        int pageCount = FrontierShopCatalog.pageCount();
        page = Math.min(page, pageCount - 1);
        int start = page * FrontierShopCatalog.PRODUCTS_PER_PAGE;
        for (int index = 0; index < PRODUCT_SLOTS.length && start + index < products.size(); index++) {
            shopInventory.setItem(PRODUCT_SLOTS[index], products.get(start + index).displayStack());
        }
        shopInventory.setItem(49, pageControl(Items.ARROW, "Previous page", page > 0));
        shopInventory.setItem(53, pageControl(Items.ARROW, "Next page", page + 1 < pageCount));
    }

    private static ItemStack pane(net.minecraft.world.item.Item item) {
        ItemStack stack = new ItemStack(item);
        stack.setHoverName(Component.literal(" "));
        return stack;
    }

    private static ItemStack balanceStack(Player player) {
        ItemStack stack = new ItemStack(Items.BOOK);
        stack.setHoverName(Component.literal("Research balance: " + AnnouncementService.points(player.getUUID())
                        + " · lifetime: " + AnnouncementService.totalEarned(player.getUUID())
                        + " · next milestone: " + milestoneText(player))
                .withStyle(ChatFormatting.AQUA));
        return stack;
    }

    private static String milestoneText(Player player) {
        int next = AnnouncementService.nextMilestone(player.getUUID());
        return next < 0 ? "complete" : Integer.toString(next);
    }

    private static ItemStack surveyStack(Player player) {
        ItemStack stack = new ItemStack(Items.COMPASS);
        stack.setHoverName(Component.literal("Survey streak: " + AnnouncementService.currentStreak(player.getUUID())
                        + " · best: " + AnnouncementService.bestStreak(player.getUUID()))
                .withStyle(ChatFormatting.GREEN));
        return stack;
    }

    private static ItemStack signalStack(FrontierLedger.SignalRecord signal) {
        ItemStack stack = new ItemStack("active".equals(signal.status) ? Items.PAPER : Items.GRAY_DYE);
        stack.setHoverName(Component.literal(signal.kindEnum().displayName() + " signal · " + signal.region
                        + " · " + signal.status)
                .withStyle("active".equals(signal.status) ? ChatFormatting.GOLD : ChatFormatting.GRAY));
        return stack;
    }

    private static ItemStack pageControl(net.minecraft.world.item.Item item, String label, boolean enabled) {
        ItemStack stack = new ItemStack(enabled ? item : Items.GRAY_DYE);
        stack.setHoverName(Component.literal(label + (enabled ? " · click" : " · unavailable"))
                .withStyle(enabled ? ChatFormatting.AQUA : ChatFormatting.DARK_GRAY));
        return stack;
    }

    private int productAt(int slotId) {
        for (int index = 0; index < PRODUCT_SLOTS.length; index++) {
            if (PRODUCT_SLOTS[index] == slotId) return page * FrontierShopCatalog.PRODUCTS_PER_PAGE + index;
        }
        return -1;
    }

    public int page() {
        return page;
    }

    public boolean canGoPrevious() {
        return page > 0;
    }

    public boolean canGoNext() {
        return page + 1 < FrontierShopCatalog.pageCount();
    }

    public int productSlotAt(int pageIndex) {
        return pageIndex >= 0 && pageIndex < PRODUCT_SLOTS.length ? PRODUCT_SLOTS[pageIndex] : -1;
    }

    /** Updates the client cursor before the server's slot synchronization arrives. */
    public void clientPageButton(int buttonId) {
        if (buttonId == BUTTON_PREVIOUS_PAGE && canGoPrevious()) page--;
        if (buttonId == BUTTON_NEXT_PAGE && canGoNext()) page++;
    }

    private boolean changePage(Player player, int delta) {
        int target = page + delta;
        if (target < 0 || target >= FrontierShopCatalog.pageCount()) return false;
        page = target;
        // The server owns the catalogue contents. The client only updates its
        // page cursor optimistically and receives the new stacks through the
        // normal container synchronization packet.
        if (player instanceof ServerPlayer serverPlayer) {
            populate(serverPlayer);
            broadcastChanges();
        }
        return true;
    }

    @Override
    public boolean clickMenuButton(Player player, int buttonId) {
        if (buttonId == BUTTON_PREVIOUS_PAGE) return changePage(player, -1);
        if (buttonId == BUTTON_NEXT_PAGE) return changePage(player, 1);
        return false;
    }

    private void purchase(ServerPlayer player, int productIndex) {
        FrontierShopProduct product = FrontierShopCatalog.products().get(productIndex);
        if (!AnnouncementService.spendPoints(player.getUUID(), product.cost())) {
            player.sendSystemMessage(Component.literal("You need " + product.cost() + " spendable research points for that item.")
                    .withStyle(ChatFormatting.RED));
            return;
        }

        ItemStack reward = product.rewardStack();
        if (!player.getInventory().add(reward)) {
            player.drop(reward, false);
        }
        player.sendSystemMessage(Component.literal("Purchased " + product.displayName() + " for " + product.cost() + " research points.")
                .withStyle(ChatFormatting.GREEN));
        populate(player);
        broadcastChanges();
    }

    @Override
    public void clicked(int slotId, int button, ClickType clickType, Player player) {
        // Every top-inventory interaction is consumed by the shop. This prevents
        // display items being removed, shift-clicked, dragged, or swapped away.
        if (slotId >= 0 && slotId < SHOP_SIZE) {
            if (clickType == ClickType.PICKUP) {
                if (slotId == 49 && page > 0) {
                    changePage(player, -1);
                    return;
                }
                if (slotId == 53 && page + 1 < FrontierShopCatalog.pageCount()) {
                    changePage(player, 1);
                    return;
                }
                if (player instanceof ServerPlayer serverPlayer) {
                    int productIndex = productAt(slotId);
                    if (productIndex >= 0 && productIndex < FrontierShopCatalog.products().size()) {
                        purchase(serverPlayer, productIndex);
                    }
                }
            }
            return;
        }
        super.clicked(slotId, button, clickType, player);
    }

    @Override
    public ItemStack quickMoveStack(Player player, int slotId) {
        // A research shop never accepts or moves ordinary inventory items.
        return ItemStack.EMPTY;
    }

    @Override
    public boolean stillValid(Player player) {
        return !player.isRemoved();
    }

    @Override
    public void removed(Player player) {
        super.removed(player);
        shopInventory.clearContent();
    }
}
